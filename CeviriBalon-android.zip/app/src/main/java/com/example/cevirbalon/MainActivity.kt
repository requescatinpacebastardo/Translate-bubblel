package com.example.cevirbalon

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.*
import androidx.core.content.edit

// Nord esintili, sakin ve profesyonel renk paleti
object Pal {
    const val BACKGROUND = 0xFFF4F6FA.toInt()
    const val CARD = 0xFFFFFFFF.toInt()
    const val TEXT = 0xFF2E3440.toInt()
    const val MUTED = 0xFF8891A3.toInt()
    const val ACCENT = 0xFF5E81AC.toInt()
    const val ACCENT_SOFT = 0xFFD8E3F0.toInt()
    const val OK = 0xFF7FB88A.toInt()
}

data class Lang(val code: String, val label: String)

object Langs {
    val list = listOf(
        Lang("en", "İngilizce"), Lang("de", "Almanca"), Lang("fr", "Fransızca"),
        Lang("es", "İspanyolca"), Lang("ru", "Rusça"), Lang("ar", "Arapça"),
        Lang("it", "İtalyanca"), Lang("pt", "Portekizce"), Lang("nl", "Felemenkçe"),
        Lang("pl", "Lehçe"), Lang("ja", "Japonca"), Lang("ko", "Korece"),
        Lang("zh", "Çince"), Lang("tr", "Türkçe")
    )
}

class MainActivity : Activity() {
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var statusAcc: TextView
    private lateinit var statusBat: TextView
    private lateinit var statusOverlay: TextView
    private lateinit var sourceSpinner: Spinner
    private lateinit var targetSpinner: Spinner

    private fun card(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(36, 32, 36, 32)
        val bg = GradientDrawable()
        bg.cornerRadius = 28f
        bg.setColor(Pal.CARD)
        l.background = bg
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = 28
        l.layoutParams = lp
        return l
    }

    private fun title(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(Pal.TEXT)
        setPadding(0, 0, 0, 16)
    }

    private fun button(text: String, bgColor: Int, fg: Int, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setTextColor(fg)
        val bg = GradientDrawable()
        bg.cornerRadius = 20f
        bg.setColor(bgColor)
        b.background = bg
        b.setPadding(28, 20, 28, 20)
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("cevir", MODE_PRIVATE)

        val root = ScrollView(this)
        root.setBackgroundColor(Pal.BACKGROUND)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(36, 72, 36, 48)
        root.addView(col)

        val header = TextView(this)
        header.text = "Çeviri Balonu"
        header.textSize = 26f
        header.setTextColor(Pal.TEXT)
        header.setPadding(0, 0, 0, 8)
        col.addView(header)

        val sub = TextView(this)
        sub.text = "Yazarken anında çeviri — her yerde, küçük bir balonda."
        sub.textSize = 13f
        sub.setTextColor(Pal.MUTED)
        sub.setPadding(0, 0, 0, 32)
        col.addView(sub)

        // Dil kartı
        val langCard = card()
        langCard.addView(title("Kaynak dil"))
        sourceSpinner = Spinner(this)
        langCard.addView(sourceSpinner)
        val sp1 = Space(this); sp1.layoutParams = LinearLayout.LayoutParams(-1, 20)
        langCard.addView(sp1)
        langCard.addView(title("Hedef dil"))
        targetSpinner = Spinner(this)
        langCard.addView(targetSpinner)
        col.addView(langCard)

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Langs.list.map { it.label })
        sourceSpinner.adapter = adapter
        targetSpinner.adapter = adapter
        val savedSrc = prefs.getString("src", "tr")
        val savedTgt = prefs.getString("tgt", "en")
        sourceSpinner.setSelection(Langs.list.indexOfFirst { it.code == savedSrc }.coerceAtLeast(0))
        targetSpinner.setSelection(Langs.list.indexOfFirst { it.code == savedTgt }.coerceAtLeast(0))

        val saveBtn = button("Dilleri kaydet", Pal.ACCENT, Color.WHITE) {
            prefs.edit {
                putString("src", Langs.list[sourceSpinner.selectedItemPosition].code)
                putString("tgt", Langs.list[targetSpinner.selectedItemPosition].code)
            }
            Toast.makeText(this, "Kaydedildi. İlk kullanımda dil paketi bir kez indirilecek.", Toast.LENGTH_LONG).show()
        }
        val sp2 = Space(this); sp2.layoutParams = LinearLayout.LayoutParams(-1, 20)
        col.addView(sp2)
        col.addView(saveBtn)

        // İzin kartı
        val sp3 = Space(this); sp3.layoutParams = LinearLayout.LayoutParams(-1, 28)
        col.addView(sp3)
        val permCard = card()
        permCard.addView(title("Kurulum"))

        statusAcc = TextView(this).apply { textSize = 13f; setPadding(0, 0, 0, 12) }
        permCard.addView(statusAcc)
        permCard.addView(button("Erişilebilirlik iznini aç", Pal.ACCENT_SOFT, Pal.TEXT) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        val spBat = Space(this); spBat.layoutParams = LinearLayout.LayoutParams(-1, 16)
        permCard.addView(spBat)
        statusBat = TextView(this).apply { textSize = 13f; setPadding(0, 0, 0, 12) }
        permCard.addView(statusBat)
        permCard.addView(button("Pil kısıtlamasını kaldır (önemli)", Pal.ACCENT, Color.WHITE) {
            requestBatteryExemption()
        })
        val note = TextView(this)
        note.text = "Bu izin kapalı kalırsa telefon, çeviri balonunu arka planda kapatabilir " +
                "ve her seferinde yeniden açman gerekir."
        note.textSize = 12f
        note.setTextColor(Pal.MUTED)
        note.setPadding(0, 10, 0, 0)
        permCard.addView(note)

        val spNotif = Space(this); spNotif.layoutParams = LinearLayout.LayoutParams(-1, 20)
        permCard.addView(spNotif)
        permCard.addView(button("Bildirim iznini ver", Pal.ACCENT_SOFT, Pal.TEXT) {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 2)
            } else {
                Toast.makeText(this, "Bu telefonda gerekli değil.", Toast.LENGTH_SHORT).show()
            }
        })
        val note2 = TextView(this)
        note2.text = "Çeviri Balonu'nun kapanmaması için küçük, sessiz bir bildirim gösterir. " +
                "Bu bildirime dokunman gerekmez."
        note2.textSize = 12f
        note2.setTextColor(Pal.MUTED)
        note2.setPadding(0, 10, 0, 0)
        permCard.addView(note2)

        val sp4 = Space(this); sp4.layoutParams = LinearLayout.LayoutParams(-1, 20)
        permCard.addView(sp4)
        col.addView(permCard)

        val info = TextView(this)
        info.text = "Nasıl kullanılır:\n\n" +
                "1) Yukarıdan dilleri seç ve kaydet.\n" +
                "2) Erişilebilirlik iznini aç ve listede \"Çeviri Balonu\"nu bul, etkinleştir.\n" +
                "3) Herhangi bir uygulamada yazı yazarken ekranda küçük yuvarlak bir buton belirir.\n" +
                "4) Butona dokunarak çeviri panelini aç/kapat, köşeye sürükleyebilirsin.\n" +
                "5) Panelde \"Kopyala\" ile çeviriyi panoya alıp yapıştırabilirsin."
        info.textSize = 13f
        info.setTextColor(Pal.MUTED)
        info.setLineSpacing(6f, 1f)
        val sp5 = Space(this); sp5.layoutParams = LinearLayout.LayoutParams(-1, 28)
        col.addView(sp5)
        col.addView(info)

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        val on = isAccessibilityOn()
        statusAcc.text = if (on) "✅ Erişilebilirlik izni açık, balon kullanılabilir." else "⚠️ Erişilebilirlik izni kapalı."
        statusAcc.setTextColor(if (on) Pal.OK else Pal.MUTED)

        val batOk = isBatteryExempt()
        statusBat.text = if (batOk) "✅ Pil kısıtlaması kapalı, uygulama arka planda kalabilir."
            else "⚠️ Pil kısıtlaması açık, telefon uygulamayı kapatabilir."
        statusBat.setTextColor(if (batOk) Pal.OK else Pal.MUTED)
    }

    private fun isAccessibilityOn(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val list = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_GENERIC)
        return list.any { it.resolveInfo.serviceInfo.packageName == packageName }
    }

    private fun isBatteryExempt(): Boolean {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun requestBatteryExemption() {
        if (isBatteryExempt()) {
            Toast.makeText(this, "Zaten açık.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            intent.data = Uri.parse("package:$packageName")
            startActivity(intent)
        } catch (e: Exception) {
            // Bazı üretici arayüzlerinde (MIUI, ColorOS vb.) bu ekran yoktur,
            // genel pil ayarlarına yönlendir.
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }
}
